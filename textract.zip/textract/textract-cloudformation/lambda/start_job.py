#!/usr/bin/env python3

import json
import time
import boto3

textract_client = boto3.client('textract')

# This is textract api which will start analysis of pdf file which will upload in the s3 bucket
def startJob(bucket_name, object_name):
    response = textract_client.start_document_analysis(
        DocumentLocation={
            'S3Object': {
                'Bucket': bucket_name,
                'Name': object_name,
            }
        },
        FeatureTypes=['TABLES', 'FORMS'],
    )

    return response["JobId"]

# Lambda function to execute main code
def lambda_handler(event, context):
    bucket_name = event['detail']['requestParameters']['bucketName']
    object_name = event['detail']['requestParameters']['key']

    print(f"StartJob: s3://{bucket_name}/{object_name}")

    job_id = startJob(bucket_name, object_name)
    print(f"JobId: {job_id}")

    return {
        "bucket_name": bucket_name,
        "object_name": object_name,
        "job_id": job_id,
        "job_start_timestamp": time.time(),
    }

# Put data in the json file using json.dump
if __name__ == "__main__":
    import sys
    with open(sys.argv[1], "rt") as f:
        event = json.load(f)
    ret = lambda_handler(event, {})
    print(json.dumps(ret, indent=2))
