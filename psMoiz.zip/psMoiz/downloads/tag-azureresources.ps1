# Input bindings are passed in via param block.
param($Timer)

# Get the current universal time in the default string format
$currentUTCtime = (Get-Date).ToUniversalTime()

### Variables  ###
$MyTag = "name"
$MyValue = "deletesunday"

## The 'IsPastDue' porperty is 'true' when the current function invocation is later than scheduled.
if ($Timer.IsPastDue) {
    Write-Host "PowerShell timer is running late!!!"
}

# Write an information log with the current time. ##
$resources=Get-AzResource

foreach ($resource in $resources) {
    $tagcount=(Get-AzResource | where-object {$_.Name -match $resource.Name}).Tags.count

    if($tagcount -eq 0) {

        Write-Host "Resource Name - "$resource.Name
        Write-Host "Resource id - "$resource.id
        Write-Host "Resource Type and RG Name : " $resource.resourcetype " & " $resource.resourcegroupname "`n"
        
       # az resource tag --tags $MyTag=$MyValue --ids $resource.id
    }
 }

Write-Host "PowerShell timer trigger function ran! TIME: $currentUTCtime && Resource Taged "