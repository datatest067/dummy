﻿#####################################
# Script : Exporting the Role Assignment Details
# Created on : 13-04-2022
#####################################

# Uncomment the below if running locally with a .env file.

#Get-Content .env | foreach {
#    $name, $value = $_.split("=")
#    Set-Content env:\$name $value
#}

####Constants####
$fileDateString = (Get-Date).ToString("dd-MMM-yyyy-HHmm")
$dateString = (Get-Date).ToString("dd-MMM-yyyy-HH:mm")

#####Variables####
$workingDirectory = (Get-Location).Path
$username = $Env:JIRA_USERNAME
$password = $Env:JIRA_PASSWORD
$project_id = "10101"
$issuetype_id = "10005"
$issue_summary = "Role Assignment Downloads - $dateString"
$issue_description = "Role assignment exports from the azure portal."
$watchers = (
    "somsejx"
)
$participants = (
    "LITECCR",
    "GADOTRX"
)

$username_and_password_string = $username + ":" + $password

$bytes = [System.Text.Encoding]::UTF8.GetBytes($username_and_password_string)
$encoded_username_and_password = [Convert]::ToBase64String($bytes)


####----Creating an function to Save the details----####
function SaveDetails([string]$RoleAssignmentId, [string]$Scope, [string]$DisplayName, [string]$SignInName, [string]$RoleDefinitionName, [string]$RoleDefinitionId, [string]$ObjectId, [string]$ObjectType, [string]$RoleAssignmentDescription , [string]$ConditionVersion, [string]$Condition){
    try {
        $assignmentDetails = New-Object -TypeName psobject
        $assignmentDetails | Add-Member -MemberType NoteProperty -Name RoleAssignmentId -Value $RoleAssignmentId
        $assignmentDetails | Add-Member -MemberType NoteProperty -Name Scope -Value $Scope
        $assignmentDetails | Add-Member -MemberType NoteProperty -Name DisplayName -Value $DisplayName
        $assignmentDetails | Add-Member -MemberType NoteProperty -Name SignInName -Value $SignInName
        $assignmentDetails | Add-Member -MemberType NoteProperty -Name RoleDefinitionName -Value $RoleDefinitionName
        $assignmentDetails | Add-Member -MemberType NoteProperty -Name RoleDefinitionId -Value $RoleDefinitionId
        $assignmentDetails | Add-Member -MemberType NoteProperty -Name ObjectId -Value $ObjectId
        $assignmentDetails | Add-Member -MemberType NoteProperty -Name ObjectType -Value $ObjectType
        $assignmentDetails | Add-Member -MemberType NoteProperty -Name RoleAssignmentDescription -Value $RoleAssignmentDescription
        $assignmentDetails | Add-Member -MemberType NoteProperty -Name ConditionVersion -Value $ConditionVersion
        $assignmentDetails | Add-Member -MemberType NoteProperty -Name Condition -Value $Condition
        $Global:roleAssignmentDetails = $Global:roleAssignmentDetails + $assignmentDetails
    }
    catch {
        Write-Warning $_.Exception
        exit 1
    }
}
## Function to add attachment to comments

Function Add-AttachmentsAsComment($ticketid, $attachmentnames) {
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("X-Atlassian-Token", "no-check")
    $headers.Add("Authorization", "Basic $encoded_username_and_password")
    $comment = ""
    ForEach ($attachmentname in $attachmentnames) {
        $comment += "[^$attachmentname]\n"
    }

    Write-Host $comment

    $payload = "{`"body`": `"$comment`"}"
    $response = Invoke-RestMethod "https://jira.merlin.net/rest/api/2/issue/$ticketid/comment" -Method 'POST' -Headers $headers -Body $payload -ContentType "application/json"
}

## Function to upload CSV to JIRA

function Upload-JiraCSV($filepath, $ticketid){
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("X-Atlassian-Token", "no-check")
    $headers.Add("Authorization", "Basic $encoded_username_and_password")

    $fileName = Split-Path $FilePath -leaf
    $fileBytes = [System.IO.File]::ReadAllBytes($FilePath);
    $fileEnc = [System.Text.Encoding]::GetEncoding('UTF-8').GetString($fileBytes);
    $boundary = [System.Guid]::NewGuid().ToString(); 
    $LF = "`r`n";

    $attachmentnames.Add($filename)

    $bodyLines = ( 
        "--$boundary",
        "Content-Disposition: form-data; name=`"file`"; filename=`"$fileName`"",
        "Content-Type: application/octet-stream$LF",
        $fileEnc,
        "--$boundary--$LF" 
    ) -join $LF

    $response = Invoke-RestMethod "https://jira.merlin.net/rest/api/2/issue/$ticketid/attachments" -Method 'POST' -Headers $headers -Body $bodyLines -ContentType "multipart/form-data; boundary=`"$boundary`""
}

function Add-JiraTicketWatchers($watcher, $ticketid) {
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("X-Atlassian-Token", "no-check")
    $headers.Add("Authorization", "Basic $encoded_username_and_password")

    $body = @"
    "$watcher"
"@

    $response = Invoke-RestMethod "https://jira.merlin.net/rest/api/2/issue/$ticketid/watchers" -Method 'POST' -Headers $headers -Body $body -ContentType "application/json"


}

function Add-JiraRequestParticipants($participant, $ticketid) {
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("X-Atlassian-Token", "no-check")
    $headers.Add("Authorization", "Basic $encoded_username_and_password")

    $body = @"
    {
        "usernames": [
            "$participant"
        ]
    }
"@

    $response = Invoke-RestMethod "https://jira.merlin.net/rest/servicedeskapi/request/$ticketid/participant/" -Method 'POST' -Headers $headers -Body $body -ContentType "application/json"
}

function Create-JiraTicket() {
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("X-Atlassian-Token", "no-check")
    $headers.Add("Authorization", "Basic $encoded_username_and_password")

    $body = @"
{
    "fields": {
       "project":
       {
          "id": "$project_id"
       },
       "summary": "$issue_summary",
       "description": "$issue_description",
       "issuetype": {
          "id": "$issuetype_id"
       },
       "customfield_10009": "ptchange/eb88664b-27dc-4f9c-bd29-07e60be1802b"
   }
}
"@

    $response = Invoke-RestMethod "https://jira.merlin.net/rest/api/2/issue" -Method 'POST' -Headers $headers -Body $body -ContentType "application/json"

    return $response.id
}

#try {

    ####----Installing Az Module----####
    #This is one time acitvity will be required only if Az module is not installed.
    #Install-Module -Name Az -Force -Scope CurrentUser

    ## Variables
    $attachmentnames = New-Object System.Collections.ArrayList

    ####----Connecting to Azure Account----####
    Write-Host "Connecting to Azure Account" -ForegroundColor Green
    $SecureString = $Env:AzureSecretString | ConvertTo-SecureString -AsPlainText -Force
    $PSCredential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $Env:AzureAppID, $SecureString
    Connect-AzAccount -ServicePrincipal -Credential $PSCredential -Tenant $Env:AzureTenantID

    ####----Fetching all the subscriptions----####
    $subscriptions = Get-AzSubscription

    Write-Host "Successfully connected to Azure" -ForegroundColor Green

    $ticket_id = Create-JiraTicket

    Write-Host "Successfully connect to JIRA" -ForegroundColor Green

    ForEach ($watcher in $watchers) {
        Add-JiraTicketWatchers -watcher $watcher -ticketid $ticket_id
    }

    Write-Host "Successfully added ticket watchers." -ForegroundColor Green
    Start-Sleep 30

    ForEach ($participant in $participants) {
        Add-JiraRequestParticipants -participant $participant -ticketid $ticket_id
    }

    Write-Host "Successfully added request participants." -ForegroundColor Green

    foreach($subscription in $subscriptions){

        Write-Host "Selecting the Azure Subscription" -ForegroundColor Green
        ####----Setting the subscription context----####
        Select-AzSubscription -Subscription $subscription.Name

        $fileName = "RoleAssignmentDetails-"+ $subscription.Name + "-" + $fileDateString + ".csv"
        $filePath = $workingDirectory + $fileName

        ####---Declaring variable to save the details---####
        $Global:roleAssignmentDetails = $null
        $Global:roleAssignmentDetails = @()

        ####----Script to Fetch the Role Assignments----####
        Write-Host "Fetching the Role Assignment Details" -ForegroundColor Green
        $roleAssignments = Get-AzRoleAssignment

        ####----Checking if role assignment is not null----####
        Write-Host "Iterating through all the Role assignments" -ForegroundColor Green
        if($roleAssignments.Count -gt 0){
            foreach ($assignment in $roleAssignments) {
            SaveDetails -RoleAssignmentId $assignment.RoleAssignmentId -Scope $assignment.Scope -DisplayName $assignment.DisplayName -SignInName $assignment.SignInName -RoleDefinitionName $assignment.RoleDefinitionName -RoleDefinitionId $assignment.RoleDefinitionId -ObjectId $assignment.ObjectId -ObjectType $assignment.ObjectType -RoleAssignmentDescription $assignment.RoleAssignmentDescription -ConditionVersion $assignment.ConditionVersion -Condition $assignment.Condition
            }
        }

        ####----Checking if File Already Exist----####
        Write-Host "Adding the details to the .csv file" -ForegroundColor Green
        if(!(Test-Path $filePath)){
            $Global:roleAssignmentDetails | Export-Csv -Path $filePath -NoTypeInformation -NoClobber
            Upload-JiraCSV -filepath $filePath -ticketid $ticket_id
                
        }
        else{
            Remove-Item -Path $filePath
            $Global:roleAssignmentDetails | Export-Csv -Path $filePath -NoTypeInformation -NoClobber
            Upload-JiraCSV -filepath $filePath -ticketid $ticket_id
        }

    }

    Add-AttachmentsAsComment -ticketid $ticket_id -attachmentnames $attachmentnames
    
    Write-Host "Script Execution Completed" -ForegroundColor Green
    exit 0
#}
#catch {
#   Write-Warning "Some error occured while script execution."
#   Write-Error $_.Exception
#   #Write-Error $response
#   exit 1
#
