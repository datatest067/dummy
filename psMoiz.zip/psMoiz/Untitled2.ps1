﻿function ConvertTo-Base64($string) {
$bytes  = [System.Text.Encoding]::UTF8.GetBytes($string);
$encoded = [System.Convert]::ToBase64String($bytes);
return $encoded;
}

function Get-HttpBasicHeader([string]$username, [string]$password, $Headers = @{}) {
    $b64 = ConvertTo-Base64 "$($username):$($Password)"
    $Headers["Authorization"] = "Basic $b64"
    $Headers["X-Atlassian-Token"] = "nocheck"
    return $Headers
}

$restapiuri = "https://stage-jira.merlin.net/rest/api/3/issue/"
#Invoke-WebRequest https://stage-jira.merlin.net/rest/api/3/issue/
$headers = Get-HttpBasicHeader "mohammed.moiz@abbott.com" "NDg4ODE3MzcyODgwOrCjEvujHJ2kEUGfzOjDu4jaSUpi"
$body = @'{"fields":   {        "project":        {            "key": "PTCHANGE"        },        "summary": "powershell issue",        "description": {          "type": "doc",          "version": 1,          "content": [            {              "type": "paragraph",              "content": [                {                  "type": "text",                  "text": "description"                }              ]            }          ]        },        "issuetype":        {            "name": "Task"        }    }}'@Invoke-RestMethod -uri $restapiuri -Headers $headers -Method POST -ContentType "application/json" -Body $body