﻿add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

$SRE_CONSUL_HTTP_TOKEN = "fbb74ca1-d0f2-4312-23dd-193a08cf0051"

$strConsulBaseURL = "https://consul.auth.products.abbott:8501/v1"

# Create a hash table with the header values we'll pass to Consul.
$hshHeaders = @{"X-Consul-Token" = "$SRE_CONSUL_HTTP_TOKEN"}  #$env:SRE_CONSUL_HTTP_TOKEN

#$dataCenters = Invoke-RestMethod -Method GET -Uri "$strConsulBaseURL/catalog/datacenters" -Headers $hshHeaders
#terraform/environments/prodtech/tf-pt-consul/-/blob/master/prod/lookup_data.tf

$rawExtensions = Invoke-RestMethod -Method GET -Uri "$strConsulBaseURL/kv/sre-data/notification_contact_information" -Headers $hshHeaders
$extensions = [System.Text.Encoding]::ASCII.GetString([System.Convert]::FromBase64String($rawExtensions.Value)) | ConvertFrom-Json
$ext = $extensions | ConvertTo-Json | Out-File 

foreach($extension_sub in $ext.subs)
        {
            Write-Host "$extension_sub"

        }

foreach($extension_main in $extensions.maintenance_contacts)
        {
            Write-Host "$extension_main"

        }
Write-Output "$extension_sub", "$extension_main"


$AzureConnection = Connect-AzAccount
$Subscriptions = (Get-AzSubscription).Id
$array = "ec10dc7a-0abb-4fee-a727-bcd9d1cfbd36"
$tenantId = '57064aa3-2825-4c10-a2e8-88c686234e09'
$applicationId = 'ddbfd72e-0c3b-4fe0-83c2-4cbc88e5f730'
$secret='Gct8Q~PfqYKPzgeYs80kw~wAdUOQFumiTZ1YHdeZ'
$LoginURL = 'https://login.microsoftonline.com'

#Define Authentication Body Part
$Body = @{ 
            grant_type = 'client_credentials'; 
            resource = 'https://management.core.windows.net/'; 
            client_id = $applicationId; 
            client_secret = $secret
        }
#Run Rest API and generate Bearer Token
$result = Invoke-RestMethod –Method Post –Uri $LoginURL/$tenantId/oauth2/token –Body $Body

    $AuthKey = "Bearer " + $result.access_token
    $authHeader = @{
        'Content-Type'  = 'application/json;charset=utf-8'
        'Accept'        = 'application/json'
        'Authorization' = $AuthKey
    }

#Get the Health of service using Events Rest APi's
for($i=0; $i -lt $Subscriptions.Count; $i++)
{
   $SetSubscription = Set-AzContext -Subscription $Subscriptions[$i]
   $subscriptionId = $Subscriptions[$i]
  if($subscriptionId -ne $array)
  {

    $SubAPI = "https://management.azure.com/subscriptions/$SubscriptionId/providers/Microsoft.ResourceHealth/events?api-version=2018-07-01&queryStartTime=2022-08-01T14%3A55%3A57Z"
    $healthData1 = Invoke-RestMethod –Uri $SubAPI –Method GET –Headers $authHeader
    Write-Output "Subscription ID $SubscriptionID"
    $user = Get-AzRoleAssignment -Scope /subscriptions/$SubscriptionID | Where-Object {$_.RoleDefinitionName -eq "Owner" -and $_.ObjectType -eq "User"} | select SignInName
    $usersdetail = $user.SignInName -join ";"
    Write-Output $usersdetail



    if($healthData1 -ne $null)
    {
        for($j=0; $j -lt $healthData1.value.Count; $j++)
        {
            if($healthData1.value[$j].properties.status -ne "Active")
            {
                
                $SubName = (Set-AzContext -Subscription $Subscriptions[$i]).Subscription.Name

                Write-Output "subNmae = $SubName"
                $ID         = $healthData1.value[$j].properties.impact[0].impactedRegions[0].impactedSubscriptions
                Write-output "ID is = $ID"
                $Name       = $healthData1.value[$j].name
                Write-output "Name is = $Name"
                $EventLevel = $healthData1.value[$j].properties.eventLevel
                Write-Output "EventLevel = $EventLevel"
                $EventType = $healthData1.value[$j].properties.eventType
                Write-Output "EventType =  $EventType"
                $Status = $healthData1.value[$j].properties.status
                Write-Output "Status of Service  =  $Status"
                $ImpactedService = $healthData1.value[$j].properties.impact[0].impactedService
                Write-Output "Impacted Service = $ImpactedService"
                $ImpactedRegion = $healthData1.value[$j].properties.impact[0].impactedRegions.impactedRegion -join ","
                Write-Output "Impacted Region = $ImpactedRegion"
                $ImpactStartTime = $healthData1.value[$j].properties.impactStartTime
                Write-Output "Service got impacted at $ImpactStartTime"
                $lastUpdateTime = $healthData1.value[$j].properties.impactStartTime
                Write-Output "Latest Dated time of Event is $lastUpdateTime"
                $click_here_for_more_information = "https://portal.azure.com/#view/Microsoft_Azure_Health/AzureHealthBrowseBlade/~/healthHistory/navigateTo/healthHistory/selectTrackingId/$Name"
                Write-Output "$click_here_for_more_information"
                write-host "`n"

                if($subName -eq "CRM" -or $subName -eq "MDD-CRM-02")
                {

                    $From = "mohammed.moiz@abbott.com"
                    #$To = "jonathan.somsen@abbott.com"
                    $To = "mohammed.moiz@abbott.com","jonathan.somsen@abbott.com"
                    $Subject = "Service Health"
                    $Body = "SubscriptionName = $SubName<br />EventLevel = $EventLevel<br /> EventType = $EventType<br /> Status of Service  =  $Status<br /> Impacted Service = $ImpactedService<br /> Impacted Region = $ImpactedRegion<br /> Service got impacted at = $ImpactStartTime<br /> Latest Dated time of Event = $lastUpdateTime<br />click_here_for_more_information = $click_here_for_more_information"
                    $SMTPServer = "smtp.ad.merlin.net"
                    $SMTPPort = "25"
                    Send-MailMessage -From $From -to $To  -Subject $Subject -Body $Body -BodyAsHtml -SmtpServer $SMTPServer -Port $SMTPPort  -Credential (Get-Credential)
               }
                elseif($subName -eq "MDD-EP-01" -or $subName -eq "MDD-EP-02")
                {
                    $From = "mohammed.moiz@abbott.com"
                    #$To = "jonathan.somsen@abbott.com"
                    $To = "mohammed.moiz@abbott.com","jonathan.somsen@abbott.com"
                    $Subject = "Service Health"
                    $Body = "SubscriptionName = $SubName<br />EventLevel = $EventLevel<br /> EventType = $EventType<br /> Status of Service  =  $Status<br /> Impacted Service = $ImpactedService<br /> Impacted Region = $ImpactedRegion<br /> Service got impacted at = $ImpactStartTime<br /> Latest Dated time of Event = $lastUpdateTime<br />click_here_for_more_information = $click_here_for_more_information"
                    $SMTPServer = "smtp.ad.merlin.net"
                    $SMTPPort = "25"
                    Send-MailMessage -From $From -to $To  -Subject $Subject -Body $Body -BodyAsHtml -SmtpServer $SMTPServer -Port $SMTPPort  -Credential (Get-Credential)
               }
                 elseif($subName -eq "MDD-RA-01" -or $subName -eq "MDD-RA-02")
                {
                    $From = "mohammed.moiz@abbott.com"
                    #$To = "jonathan.somsen@abbott.com"
                    $To = "mohammed.moiz@abbott.com","jonathan.somsen@abbott.com"
                    $Subject = "Service Health"
                    $Body = "SubscriptionName = $SubName<br />EventLevel = $EventLevel<br /> EventType = $EventType<br /> Status of Service  =  $Status<br /> Impacted Service = $ImpactedService<br /> Impacted Region = $ImpactedRegion<br /> Service got impacted at = $ImpactStartTime<br /> Latest Dated time of Event = $lastUpdateTime<br />click_here_for_more_information = $click_here_for_more_information"
                    $SMTPServer = "smtp.ad.merlin.net"
                    $SMTPPort = "25"
                    Send-MailMessage -From $From -to $To  -Subject $Subject -Body $Body -BodyAsHtml -SmtpServer $SMTPServer -Port $SMTPPort  -Credential (Get-Credential)
               }
                 elseif($subName -eq "MDD-HF-01")
                {
                    $From = "mohammed.moiz@abbott.com"
                    #$To = "jonathan.somsen@abbott.com"
                    $To = "mohammed.moiz@abbott.com","jonathan.somsen@abbott.com"
                    $Subject = "Service Health"
                    $Body = "SubscriptionName = $SubName<br />EventLevel = $EventLevel<br /> EventType = $EventType<br /> Status of Service  =  $Status<br /> Impacted Service = $ImpactedService<br /> Impacted Region = $ImpactedRegion<br /> Service got impacted at = $ImpactStartTime<br /> Latest Dated time of Event = $lastUpdateTime<br />click_here_for_more_information = $click_here_for_more_information"
                    $SMTPServer = "smtp.ad.merlin.net"
                    $SMTPPort = "25"
                    Send-MailMessage -From $From -to $To  -Subject $Subject -Body $Body -BodyAsHtml -SmtpServer $SMTPServer -Port $SMTPPort  -Credential (Get-Credential)
               }
                 elseif($subName -eq "MDD-NU-01" -or $subName -eq "MDD-NU-02")
                { $From = "mohammed.moiz@abbott.com"
                    #$To = "jonathan.somsen@abbott.com"
                    $To = "mohammed.moiz@abbott.com","jonathan.somsen@abbott.com"
                    $Subject = "Service Health"
                    $Body = "SubscriptionName = $SubName<br />EventLevel = $EventLevel<br /> EventType = $EventType<br /> Status of Service  =  $Status<br /> Impacted Service = $ImpactedService<br /> Impacted Region = $ImpactedRegion<br /> Service got impacted at = $ImpactStartTime<br /> Latest Dated time of Event = $lastUpdateTime<br />click_here_for_more_information = $click_here_for_more_information"
                    $SMTPServer = "smtp.ad.merlin.net"
                    $SMTPPort = "25"
                    Send-MailMessage -From $From -to $To  -Subject $Subject -Body $Body -BodyAsHtml -SmtpServer $SMTPServer -Port $SMTPPort  -Credential (Get-Credential)
              }

                elseif($subName -eq "MDD-PT-01" -or $subName -eq "MDD-PT-02" -or $subName -eq "MDD-PT-03")
                { 
                   $From = "mohammed.moiz@abbott.com"
                    #$To = "jonathan.somsen@abbott.com"
                    $To = "mohammed.moiz@abbott.com","jonathan.somsen@abbott.com"
                    $Subject = "Service Health"
                    $Body = "SubscriptionName = $SubName<br />EventLevel = $EventLevel<br /> EventType = $EventType<br /> Status of Service  =  $Status<br /> Impacted Service = $ImpactedService<br /> Impacted Region = $ImpactedRegion<br /> Service got impacted at = $ImpactStartTime<br /> Latest Dated time of Event = $lastUpdateTime<br />click_here_for_more_information = $click_here_for_more_information"
                    $SMTPServer = "smtp.ad.merlin.net"
                    $SMTPPort = "25"
                    Send-MailMessage -From $From -to $To  -Subject $Subject -Body $Body -BodyAsHtml -SmtpServer $SMTPServer -Port $SMTPPort  -Credential (Get-Credential)
              }
              else{
               write-host "no subscritpion found"
              }

            }
        }
    }
   }
} 
