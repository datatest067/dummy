﻿$context = Get-AzSubscription -SubscriptionId bef164d0-396c-4064-b5b0-2d2d9d986f4f

 Set-AzContext $context

 $vault = Get-AzRecoveryServicesVault -ResourceGroupName p1-nuin-rg52 -Name p1-nuin-rg52-rcv1

 $joblist=Get-AzRecoveryServicesBackupJob -Status "Failed" -VaultId $vault.ID

 Write-Output $joblist

 $vault = Get-AzRecoveryServicesVault -ResourceGroupName p1-nuin-rg52 -Name p1-nuin-rg52-rcv1

 $NamedContainer1 = Get-AzRecoveryServicesBackupContainer -ContainerType AzureVM -Status Registered -FriendlyName "s1-ox-api-l521.auth.products.abbott" -VaultId $vault.ID

 $Item1 = Get-AzRecoveryServicesBackupItem -Container $NamedContainer1 -WorkloadType AzureVM -VaultId $vault.ID

 $Job1 = Backup-AzRecoveryServicesBackupItem -Item $Item1 -VaultId $vault.ID

 $job1.Status

 
$vault2 = Get-AzRecoveryServicesVault -ResourceGroupName "p1-nuin-rg52" -Name "p1-nuin-rg52-rcv1"

$vault2.Identity | fl

$vault = Get-AzRecoveryServicesVault -ResourceGroupName "resourceGroup" -Name "vaultName"

$Jobs = Get-AzRecoveryServicesBackupJob -Status InProgress -VaultId $vault.ID


While ( $Job.Status -ne "Completed" ) {
    Write-Host -Object "Waiting for completion..."
    Start-Sleep -Seconds 180
    $Job = Get-AzRecoveryServicesBackupJob -Job $Job -VaultId $vault.ID
}
if($Job.Status -eq "Completed") 
 {
    Send-MailMessage -From 'moiz <mohammed.moiz@abbott.com>' -To 'moiz <mohammed.moiz@abbott.com>' -Subject 'Sending the Attachment' -Body "Forgot to send the attachment. Sending now."   -SmtpServer 'smtp.auth.products.abbott'
 }
 


Waiting for completion... 
Waiting for completion... 
Waiting for completion... 
Done!





 q1-ue-bld-l521.auth.products.abbott


 Activity ID

aeea0b1a-eb93-46a4-b2b0-248a91efbbd1