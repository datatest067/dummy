﻿$AzureConnection = Connect-AzAccount
$Subscriptions = Get-AzSubscription
#$Approved_ext = Get-Content -Path $HOME\Desktop\Allversionnumbersvmextentionlist.csv
$CSVFileLocation = New-Item $HOME\Desktop\Allversionnumbersvmextentionlistwithvmname.json


for($i=0; $i -lt $Subscriptions.Count; $i++)
{
      $SetSubscription = Set-AzContext -Subscription $Subscriptions[$i]
     
      $Resource = Get-AzResource | Where-Object {$_.ResourceType -eq "Microsoft.Compute/virtualMachines"}
      $ResourceName = $Resource.ResourceName
      foreach($resource in $ResourceName)
      {
   
      $ResourceGroupName = (Get-AzResource -Name $Resource).ResourceGroupName
      $vm_name = Get-AzVM -ResourceGroupName $ResourceGroupName
      foreach($vm_new in $vm_name){
      $vm_ext = Get-AzVMExtension -VMNAME $vm_new.Name -ResourceGroupName  $vm_new.ResourceGroupName | select  Name, TypeHandlerVersion
      $vm_ext | ConvertTo-Json | Out-File -Append $CSVFileLocation -Encoding string
      
             
       }

   }
}
