﻿#KeyVault Network Rule
$AzureConnection = Connect-AzAccount
$Subscriptions = Get-AzSubscription
$CSVFileLocation = "$HOME\Desktop\test.csv"
for($i=0; $i -lt $Subscriptions.Count; $i++)
{
      $SetSubscription = Set-AzContext -Subscription $Subscriptions[$i]
      #Get All KeyVault Details
      $Resource = Get-AzResource | Where-Object {$_.ResourceType -eq "Microsoft.KeyVault/vaults"}

      #Set Resource variable
      $ResourceName = $Resource.ResourceName
      $ResourceGroupName = $Resource.ResourceGroupName
      $i = 0;
      #Store Keyvault Name into csv if NetworkRule is set to 0
      foreach($rg in $ResourceGroupName) 
      {
            $KeyVaultVNet = (Get-AzKeyVault -ResourceGroupName $ResourceGroupName[$i] -VaultName $ResourceName[$i]).NetworkAcls.VirtualNetworkResourceIds
            if(!$KeyVaultVNet)
            {
                $ResourceName[$i] | Out-File -Append $CSVFileLocation -Encoding string
            }
            $i++;
      }
}