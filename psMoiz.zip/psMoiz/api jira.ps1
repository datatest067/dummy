﻿$fileDateString = (Get-Date).ToString("dd-MMM-yyyy-HHmm")
$dateString = (Get-Date).ToString("dd-MMM-yyyy-HH:mm")

#####Variables####
$workingDirectory = "C:\Test\"
$token = "ODgwMjQ3MjAxOTAxOn6p3ooy3MzO0ACjBjHqRMjAFGHI" ## Follow instructions at https://confluence.atlassian.com/enterprise/using-personal-access-tokens-1026032365.html to create token.
$project_id = "10101"
$issuetype_id = "10005"
$issue_summary = "$vmname has Non White LIsted extension(s) $ext"
$issue_description = "$vmname has Non White LIsted extension(s) $ext."
$watchers = (
    "somsejx",
    "FATOKOX"
)

function Add-JiraTicketWatchers($watcher, $ticketid) {
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("X-Atlassian-Token", "no-check")
    $headers.Add("Authorization", "Bearer $token")

    $body = @"
    "$watcher"
"@

    $response = Invoke-RestMethod "https://jira.merlin.net/rest/api/2/issue/$ticketid/watchers" -Method 'POST' -Headers $headers -Body $body -ContentType "application/json"
}

function Create-JiraTicket() {
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("X-Atlassian-Token", "no-check")
    $headers.Add("Authorization", "Bearer $token")

    $body = @"
{
    "fields": {
       "project":
       {
          "id": "$project_id"
       },
       "summary": "$issue_summary",
       "description": "$issue_description",
       "issuetype": {
          "id": "$issuetype_id"
       }
   }
}
"@

    $response = Invoke-RestMethod "https://jira.merlin.net/rest/api/2/issue" -Method 'POST' -Headers $headers -Body $body -ContentType "application/json"

    return $response.id
}
    Write-Host "Connecting to Azure Account" -ForegroundColor Green 

    $ticket_id = Create-JiraTicket

    ForEach ($watcher in $watchers) {
        Add-JiraTicketWatchers -watcher $watcher -ticketid $ticket_id
    }
    
    Write-Host "Script Execution Completed" -ForegroundColor Green
