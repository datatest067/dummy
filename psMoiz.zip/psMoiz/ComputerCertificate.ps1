﻿#auth.products.abbott CA location "p1-in-cawb-w201.auth.products.abbott\P1-IN-CAWB-W201"
#ad.merlin.net CA location "p1-in-ca-w201a.ad.merlin.net\Prod Tech Enterprise Certificate Authority"


#function get-ExpiringCerts ($duedays=60,$CAlocation="p1-in-cawb-w201.auth.products.abbott\P1-IN-CAWB-W201") {
  $duedays=60
  $CAlocation="p1-in-cawb-w201.auth.products.abbott\P1-IN-CAWB-W201"
  $certs = @()
  $now = get-Date;
  $expirationdate = $now.AddDays($duedays)
  $CaView = New-Object -Com CertificateAuthority.View.1
  [void]$CaView.OpenConnection($CAlocation)
  $CaView.SetResultColumnCount(5)
  $index0 = $CaView.GetColumnIndex($false, "Issued Common Name")
  $index1 = $CaView.GetColumnIndex($false, "Certificate Expiration Date")
  $index2 = $CaView.GetColumnIndex($false, "Issued Email Address")
  $index3 = $CaView.GetColumnIndex($false, "Certificate Template")
  $index4 = $CaView.GetColumnIndex($false, "Request Disposition")
  $index0, $index1, $index2, $index3, $index4 | %{$CAView.SetResultColumn($_) }

  # CVR_SORT_NONE 0
  # CVR_SEEK_EQ  1
  # CVR_SEEK_LT  2
  # CVR_SEEK_GT  16

  $index1 = $CaView.GetColumnIndex($false, "Certificate Expiration Date")
  $CAView.SetRestriction($index1,16,0,$now)
  $CAView.SetRestriction($index1,2,0,$expirationdate)

  # brief disposition code explanation:
  # 9 - pending for approval
  # 15 - CA certificate renewal
  # 16 - CA certificate chain
  # 20 - issued certificates
  # 21 - revoked certificates
  # all other - failed requests
  
  $CAView.SetRestriction($index4,1,0,20)

  $RowObj= $CAView.OpenView() 

  while ($Rowobj.Next() -ne -1){
    $Cert = New-Object PsObject
    $ColObj = $RowObj.EnumCertViewColumn()
    [void]$ColObj.Next()
    do {
      $current = $ColObj.GetName()
      $Cert | Add-Member -MemberType NoteProperty $($ColObj.GetDisplayName()) -Value $($ColObj.GetValue(1)) -Force  
    } until ($ColObj.Next() -eq -1)
    Clear-Variable ColObj
    $datediff = New-TimeSpan -Start ($now) -End ($cert."Certificate Expiration Date")
    
    if ($cert."Issued Common Name" -ne $null) {  
    "Certificate " + $cert."Issued Common Name" + " will expire in " + $dateDiff.Days + " days at " + $cert."Certificate Expiration Date"
    #"Send email to : " + $cert."Issued Email Address"
    "------------------------"
    }
  }
  $RowObj.Reset()
  $CaView = $null
  [GC]::Collect()
#}

#get-ExpiringCerts -duedays 365 -CAlocation "p1-in-cawb-w201.auth.products.abbott\P1-IN-CAWB-W201"
