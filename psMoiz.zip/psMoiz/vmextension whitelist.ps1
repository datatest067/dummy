﻿$AzureConnection = Connect-AzAccount
$Subscriptions = Get-AzSubscription
$Approved_ext = Get-Content -Path $HOME\Desktop\wl.json
$CSVFileLocation = New-Item $HOME\Desktop\Allversionnumbersvmextentionlistwithvmname.json

for($i=0; $i -lt $Subscriptions.Count; $i++)
{
      $SetSubscription = Set-AzContext -Subscription $Subscriptions[$i]
     
      $Resource = Get-AzResource | Where-Object {$_.ResourceType -eq "Microsoft.Compute/virtualMachines"}
      $ResourceName = $Resource.ResourceName
      foreach($resource in $ResourceName)
      {
   
      $ResourceGroupName = (Get-AzResource -Name $Resource).ResourceGroupName
      $vm_name = Get-AzVM -ResourceGroupName $ResourceGroupName
      foreach($vm_new in $vm_name){
        $vm_extension = (Get-AzVMExtension -VMNAME $vm_new.Name -ResourceGroupName  $vm_new.ResourceGroupName).Name
        $vmname = $vm_new.Name
        $vmext = $vm_extension
        $vmext | Out-File -Append $CSVFileLocation -Encoding string
        # Write-Output "vmname" $vm_new.Name
        foreach($ext in $vm_extension) {
          if($ext -in $Approved_ext) {
            Write-Output "extention Does Exist = $ext"
            }
          else {
                  Write-Output "extention Doesn't Exist = $ext"
             }
           }
             
       }

   }
}
