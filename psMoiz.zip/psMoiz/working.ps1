﻿$context = Get-AzSubscription -SubscriptionId 2f6c33c4-e7cf-4ea9-8bd7-2acd40ae92b4

 Set-AzContext $context

 $vault = Get-AzRecoveryServicesVault -ResourceGroupName p1-nuin-rg611 -Name p1-nuin-rcv611

 $joblist=Get-AzRecoveryServicesBackupJob -Status "Failed" -VaultId $vault.ID

 Write-Output=$joblist


 $NamedContainer = Get-AzRecoveryServicesBackupContainer -ContainerType AzureVM -Status Registered -FriendlyName "q1-ox-api-l611.auth.products.abbott" -VaultId $vault.ID

 $Item = Get-AzRecoveryServicesBackupItem -Container $NamedContainer -WorkloadType AzureVM -VaultId $vault.ID

 $Job = Backup-AzRecoveryServicesBackupItem -Item $Item -VaultId $vault.ID

 $job.Status

 $job.ActivityId


While ( $Job.Status -ne "Completed" ) {
    Write-Host -Object "Waiting for completion..."
    Start-Sleep -Seconds 180
    $Job = Get-AzRecoveryServicesBackupJob -Job $Job -VaultId $vault.ID
}
if($Job.Status -eq "Completed") 
 {
    Send-MailMessage -From 'moiz <mohammed.moiz@abbott.com>' -To 'moiz <mohammed.moiz@abbott.com>' -Subject 'Recovery Backup Job resumed and completed successfully' -Body "$Job.ActivityId Recovery Backup Job resumed and completed successfully"   -SmtpServer 'smtp.auth.products.abbott'
 }
 

Waiting for completion... 
Waiting for completion... 
Waiting for completion... 
Done!






 