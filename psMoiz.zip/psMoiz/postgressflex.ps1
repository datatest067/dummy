﻿$AzureConnection = Connect-AzAccount
$Subscriptions = Get-AzSubscription
$CSVFileLocation = "$HOME\Desktop\postgreflexi.csv"

for($i=0; $i -lt $Subscriptions.Count; $i++)
{
  $SetSubscription = Set-AzContext -Subscription $Subscriptions[$i]
      $Resource = Get-AzResource | Where-Object {$_.ResourceType -eq "Microsoft.DBforPostgreSQL/flexibleServers"}
      $ResourceName = $Resource.ResourceName
      $ResourceGroupName = $Resource.ResourceGroupName
      Write-Output "**"
      Write-Output $ResourceName
      write-output "**"    
      foreach($resource in $ResourceName)
      {
         $ResourceGroupName = (Get-AzResource -Name $Resource).ResourceGroupName
            $postgreSQLVNet = (Get-AzPostgreSqlFlexibleServerFirewallRule -ResourceGroupName $ResourceGroupName -ServerName $Resource).VirtualNetworkSubnetId
            if(!$postgreSQLVNet)
                {
                    $ResourceN | Out-File -Append $CSVFileLocation -Encoding string
                }
         }
 }