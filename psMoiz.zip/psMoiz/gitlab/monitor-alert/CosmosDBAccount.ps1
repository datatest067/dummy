﻿connect-azaccount

$subs=Get-AzSubscription
for($i=0; $i -lt $subs.Count; $i++)
{
      Set-AzContext -Subscription $subs[$i]
      $Resource = Get-AzResource | Where-Object {$_.ResourceType -eq "Microsoft.DocumentDB/databaseAccounts"}
      $ResourceName = $Resource.ResourceName
      $ResourceGroupName = $Resource.ResourceGroupName
      #$cosmosdbname=Get-AzCosmosDBAccount -ResourceGroupName t1-va-vdl-rg52
      foreach($rg in $ResourceGroupName) {
            $Result=@()
            $Cosmosdb = Get-AzCosmosDBAccount -ResourceGroupName $rg
            $Cosmosdb | ForEach-Object {
            $cosmosdb = $_ 
            Get-AzCosmosDBAccount -ResourceGroupName $rg -Name $cosmosdb.Name  | ForEach-Object {

            $Result += New-Object PSObject -property @{
            CosmosName = $cosmosdb.Name
           # ResourceGroup = $cosmosdb.ResourceGroupName
            PublicNetworkAccess = $cosmosdb.PublicNetworkAccess
            NetworkAclBypass = $cosmosdb.NetworkAclBypass
            NetworkAclBypassResourceIds = $cosmosdb.NetworkAclBypassResourceIds
            IpRules = $cosmosdb.IpRules
            VirtualNetworkRules = $cosmosdb.VirtualNetworkRules

    }
    }
    }
    $Result | Select CosmosName,PublicNetworkAccess,NetworkAclBypass,NetworkAclBypassResourceIds,IpRules,VirtualNetworkRules 
    }
       }
  