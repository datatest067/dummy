﻿connect-azaccount
$subs=Get-AzSubscription
for($i=0; $i -lt $subs.Count; $i++)
{
      Set-AzContext -Subscription $subs[$i]
      $Resource = Get-AzResource | Where-Object {$_.ResourceType -eq "Microsoft.KeyVault/vaults"}
      $ResourceName = $Resource.ResourceName
      $ResourceGroupName = $Resource.ResourceGroupName
      #$cosmosdbname=Get-AzCosmosDBAccount -ResourceGroupName t1-va-vdl-rg52
      foreach($rg in $ResourceGroupName) {
            $Result=@()
            $KeyVault = Get-AzKeyVault -ResourceGroupName $rg
            $KeyVault | ForEach-Object {
            $keyvault = $_ 
            Get-AzKeyVault -ResourceGroupName $rg -VaultName $keyvault.VaultName  | ForEach-Object {

            $Result += New-Object PSObject -property @{
            VaultName = $keyvault.VaultName
           # ResourceGroup = $cosmosdb.ResourceGroupName
            PublicNetworkAccess = $keyvault.PublicNetworkAccess
            NetworkAclBypass = $keyvault.NetworkAclBypass
            NetworkAclBypassResourceIds = $keyvault.NetworkAclBypassResourceIds
            IpRules = $keyvault.IpRules
            VirtualNetworkRules = $keyvault.VirtualNetworkRules

    }
    }
    }
    $Result | Select VaultName,PublicNetworkAccess,NetworkAclBypass,NetworkAclBypassResourceIds,IpRules,VirtualNetworkRules 
    }
       }

