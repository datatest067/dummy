﻿connect-azaccount
$subs=Get-AzSubscription
for($i=0; $i -lt $subs.Count; $i++)
{
      Set-AzContext -Subscription $subs[$i]
          $sqlservername= Get-AzSqlServer
          for($i=0; $i -lt $sqlservername.Count; $i++)
          {
            (get-azsqlserver -ResourceGroupName $sqlservername[$i].ResourceGroupName -ServerName $sqlservername[$i].ServerName).ServerName
            Get-AzSqlServerVirtualNetworkRule -ResourceGroupName $sqlservername[$i].ResourceGroupName -ServerName $sqlservername[$i].ServerName

     write-output "######################"       
          }
          write-output "nextsubscription"

}

