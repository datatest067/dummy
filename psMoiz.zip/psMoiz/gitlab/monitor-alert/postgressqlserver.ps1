﻿connect-azaccount

$subs=Get-AzSubscription
for($i=0; $i -lt $subs.Count; $i++)
{
      Set-AzContext -Subscription $subs[$i]
      $Resource = Get-AzResource | Where-Object {$_.ResourceType -eq "Microsoft.DBforPostgreSQL/servers"}
      $ResourceName = $Resource.ResourceName
      $ResourceGroupName = $Resource.ResourceGroupName
      foreach($rg in $ResourceGroupName) {
            $Result=@()
            $Postgres = Get-AzPostgreSqlServer -ResourceGroupName $rg
            $Postgres| ForEach-Object {
            $Postgres = $_ 
            Get-AzPostgreSqlServer -ResourceGroupName $rg -Name $postgres.Name  | ForEach-Object {

            $Result += New-Object PSObject -property @{
            PostgresName = $postgres.Name
           # ResourceGroup = $cosmosdb.ResourceGroupName
            PublicNetworkAccess = $postgres.PublicNetworkAccess
            NetworkAclBypass = $postgres.NetworkAclBypass
            NetworkAclBypassResourceIds = $postgres.NetworkAclBypassResourceIds
            IpRules = $postgres.IpRules
            VirtualNetworkRules = $postgres.VirtualNetworkRules

    }
    }
    }
    $Result | Select PostgresName,PublicNetworkAccess,NetworkAclBypass,NetworkAclBypassResourceIds,IpRules,VirtualNetworkRules 
    }
       } 