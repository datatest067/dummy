﻿  $secret = "Sq57Q~xh4rG8L4orWc4v-rMG0De-FaEZ-cTrn"
  $tenant = "57064aa3-2825-4c10-a2e8-88c686234e09"
  $appid = "ace16338-5668-4337-ac70-b2190796d10e"
 $secpasswd = ConvertTo-SecureString -String $secret  -AsPlainText -Force
 $Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $appid, $secpasswd 
Connect-AzAccount -ServicePrincipal -TenantId $tenant  -Credential $Credential 
                                        
 "Login successful.."
    
 get-azcontext
    
 
    
 #$subscriptions = Get-AzSubscription | foreach {$_.SubscriptionId}
$subs=Get-AzSubscription
foreach($sub in $subs){

  Set-AzContext -Subscription $sub.id -Force
  $resourcegroups= Get-AzResourceGroup
  Write-Host "Currently connected  to subscription"$sub.id -ForegroundColor red -BackgroundColor white

  foreach($rg in $resourcegroups){

    Write-Host "Current resourcegroup"$rg.ResourceGroupName -ForegroundColor Yellow -BackgroundColor Black
    Write-Host "Here are list of resources present in this resource group:" -ForegroundColor Cyan 
    $Result=@()
    $Storageaccounts = Get-AzStorageAccount -ResourceGroupName $rg.ResourceGroupName
    $Storageaccounts | ForEach-Object {
    $storageaccount = $_
    Get-AzStorageAccountNetworkRuleSet -ResourceGroupName $storageaccount.ResourceGroupName -AccountName $storageaccount.StorageAccountName | ForEach-Object {
    $Result += New-Object PSObject -property @{ 
    Account = $storageaccount.StorageAccountName
    ResourceGroup = $storageaccount.ResourceGroupName
    Bypass = $_.Bypass
    Action = $_.DefaultAction
    IPrules = $_.IpRules
    Vnetrules = $_.VirtualNetworkRules
    ResourceRules = $_.ResourceAccessRules
    }
    }
    }
    $Result | Select Account,ResourceGroup,Bypass,Action,IPrules,Vnetrules,ResourceRules
      
    

      }
    } 