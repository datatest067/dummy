﻿ #KeyVault Network Rule
$AzureConnection = Connect-AzAccount
$Subscriptions = Get-AzSubscription

$CSVFileLocation = "$HOME\Desktop\KeyVault.csv"
for($i=0; $i -lt $Subscriptions.Count; $i++)
{
      $SetSubscription = Set-AzContext -Subscription $Subscriptions[$i]
      $SetSub = Set-AzContext -Subscription "bef164d0-396c-4064-b5b0-2d2d9d986f4f"
      #Get All KeyVault Details
      $Resource = Get-AzResource | Where-Object {$_.ResourceType -eq "Microsoft.KeyVault/vaults"}

      #Set Resource variable
      $ResourceName = $Resource.ResourceName
      $ResourceGroupName = $Resource.ResourceGroupName
      $ResourceName = "d1-nu-cr-sec-kv521"
      $ResourceGroupName = "d1-nu-cr-rg52"
      $i = 0;
      #Store Keyvault Name into csv if NetworkRule is set to 0
      foreach($rg in $ResourceGroupName) 
      {
            $Result=@()
            $KeyVault = Get-AzKeyVault -ResourceGroupName $ResourceGroupName[$i]
            $KeyVaultSecret = Get-azkeyvaultsecret -VaultName $KeyVault.VaultName
            $keyVaultSecret | ForEach-Object {
            $KeyVaultSecret = $_
            $i = 0;
            $CSVFileLocation = "$HOME\Desktop\keysecret.csv"
            $secret = Get-AzKeyVaultSecret -VaultName $keyVault.VaultName -Name $KeyVaultSecret.Name
            # | ForEach-Object {
            
            if(!$KeyVaultSecret)
            {
                $ResourceName[$i] | Out-File -Append $CSVFileLocation -Encoding string
            }
            $i++;
            $Result += New-Object PSOject -Property @{
            VaultName = $KeyVaultSecret.VaultName
            SecretName = $KeyVaultSecret.Name
            ExpireDate = $KeyVaultSecret.Expires
            KeyId = $KeyVaultSecret.Id

       }
       }
       }

}
}

















































