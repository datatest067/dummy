﻿$AzureConnection = Connect-AzAccount
$Subscriptions = Get-AzSubscription
$Approved_ext = Get-Content -Path $HOME\Desktop\test.csv


for($i=0; $i -lt $Subscriptions.Count; $i++)
{
      $SetSubscription = Set-AzContext -Subscription $Subscriptions[$i]
     
      $Resource = Get-AzResource | Where-Object {$_.ResourceType -eq "Microsoft.Compute/virtualMachines"}
      $ResourceName = $Resource.ResourceName
      foreach($resource in $ResourceName)
      {
   
      $ResourceGroupName = (Get-AzResource -Name $Resource).ResourceGroupName
      $vm_name = Get-AzVM -ResourceGroupName $ResourceGroupName
      foreach($vm_new in $vm_name){
        $vm_extension = (Get-AzVMExtension -VMNAME $vm_new.Name -ResourceGroupName  $vm_new.ResourceGroupName).Name
        $vmname = $vm_new.Name
        $vmext = $vm_extension
         Write-Output "vmname" $vm_new.Name
        foreach($ext in $vm_extension) {
          if($ext -in $Approved_ext) {
            Write-Output "extention Does Exist = $ext"
            }
          else {
            $fileDateString = (Get-Date).ToString("dd-MMM-yyyy-HHmm")
            $dateString = (Get-Date).ToString("dd-MMM-yyyy-HH:mm")

#####Variables####
            $workingDirectory = "C:\Test\"
            $token = "ODgwMjQ3MjAxOTAxOn6p3ooy3MzO0ACjBjHqRMjAFGHI" ## Follow instructions at https://confluence.atlassian.com/enterprise/using-personal-access-tokens-1026032365.html to create token.
            $project_id = "10101"
            $issuetype_id = "10005"
            $issue_summary = "$vmname has Non White LIsted extension(s) "
            $issue_description = "$vmname has Non White LIsted extension(s) $ext."
            $watchers = (
            "somsejx",
            "FATOKOX"
            )

            function Add-JiraTicketWatchers($watcher, $ticketid) {
            $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
            $headers.Add("X-Atlassian-Token", "no-check")
            $headers.Add("Authorization", "Bearer $token")

            $body = @"
            "$watcher"
"@

            $response = Invoke-RestMethod "https://jira.merlin.net/rest/api/2/issue/$ticketid/watchers" -Method 'POST' -Headers $headers -Body $body -ContentType "application/json"
            }

            function Create-JiraTicket() {
            $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
            $headers.Add("X-Atlassian-Token", "no-check")
            $headers.Add("Authorization", "Bearer $token")

            $body = @"
            {
            "fields": {
            "project":
            {
            "id": "$project_id"
              },
            "summary": "$issue_summary",
            "description": "$issue_description",
            "issuetype": {
            "id": "$issuetype_id"
             }
             }
             }
"@

             $response = Invoke-RestMethod "https://jira.merlin.net/rest/api/2/issue" -Method 'POST' -Headers $headers -Body $body -ContentType "application/json"

             return $response.id
             }
             Write-Host "Connecting to Azure Account" -ForegroundColor Green 

             $ticket_id = Create-JiraTicket

              ForEach ($watcher in $watchers) {
              Add-JiraTicketWatchers -watcher $watcher -ticketid $ticket_id
              }
    
             Write-Host "Script Execution Completed" -ForegroundColor Green


             Write-Output "extention Doesn't Exist = $ext"
             }
           }
             
       }

   }
}
