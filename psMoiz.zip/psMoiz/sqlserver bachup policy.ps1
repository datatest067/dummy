﻿$AzureConnection = Connect-AzAccount$Subscriptions = Get-AzSubscription$CSVFileLocation = "$HOME\Desktop\sqlserverDB.csv"

for($i=0; $i -lt $Subscriptions.Count; $i++)
{
      $SetSubscription = Set-AzContext -Subscription $Subscriptions[$i]
      $SQLServers = Get-AzSqlServer

          for($i=0; $i -lt $SQLServers.Count; $i++)
          {
              $Resource = Get-AzResource | Where-Object {$_.ResourceType -eq "Microsoft.Sql/servers"}
              $ResourceName = $Resource.ResourceName

              foreach($res in $ResourceName)
    {          
                $ResourceGroupName = (Get-AzResource -Name $Res).ResourceGroupName
                $dbname = (Get-AzSqlDatabase -ResourceGroupName $ResourceGroupName -ServerName $res).DatabaseName
                 foreach($db in $dbname){
                 
                  


                  if($db -contains "master")
                  {
                      Write-Host "long term policy not supported"
                  }
                  else{
                      $backup= Get-AzSqlDatabaseBackupLongTermRetentionPolicy -ResourceGroupName $ResourceGroupName -ServerName $res -DatabaseName $db
                      $backup | Out-File -Append $CSVFileLocation -Encoding string
                    }
}
}
}
} 