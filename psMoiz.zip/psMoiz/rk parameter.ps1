﻿$subscriptionName = 2f6c33c4-e7cf-4ea9-8bd7-2acd40ae92b4

$context = Get-AzSubscription -SubscriptionId $subscriptionName

 Set-AzContext $context

$ServiceName = Get-AzRecoveryServicesVault


 $vault1 = Get-AzRecoveryServicesVault -ResourceGroupName $ServiceName.ResourceGroupName -Name $ServiceName.Name

 

 $joblist1=Get-AzRecoveryServicesBackupJob -Status "Failed" -VaultId $vault1.ID

Write-Output $joblist1|Select-Object WorkloadName,Status,Starttime,Endtime,JobID|Out-File -FilePath C:\Users\MOIZMX\Documents\ps14778.txt

$Worklist=$joblist1|Select-Object WorkloadName,Status,Starttime,Endtime,JobID

 Get-Content -Path C:\Users\MOIZMX\Documents\ps.txt|Select-Object WorkloadName




 $NamedContainer = Get-AzRecoveryServicesBackupContainer -ContainerType AzureVM -Status Registered -FriendlyName "q1-ox-api-l611.auth.products.abbott" -VaultId $vault.ID

 $Item = Get-AzRecoveryServicesBackupItem -Container $NamedContainer -WorkloadType AzureVM -VaultId $vault.ID

 $Job = Backup-AzRecoveryServicesBackupItem -Item $Item -VaultId $vault.ID

 $job.Status

 $job.ActivityId

 $vault = Get-AzRecoveryServicesVault -ResourceGroupName "resourceGroup" -Name "vaultName"

$Jobs = Get-AzRecoveryServicesBackupJob -Status InProgress -VaultId $vault.ID

$Job = $Jobs[0]

While ( $Job.Status -ne "Completed" ) {
    Write-Host -Object "Waiting for completion..."
    Start-Sleep -Seconds 180
    $Job = Get-AzRecoveryServicesBackupJob -Job $Job -VaultId $vault.ID
}
if($Job.Status -eq "Completed") 
 {
    Send-MailMessage -From 'moiz <mohammed.moiz@abbott.com>' -To 'moiz <mohammed.moiz@abbott.com>' -Subject 'Recovery Backup Job resumed and completed successfully' -Body "$Job.ActivityId Recovery Backup Job resumed and completed successfully"   -SmtpServer 'smtp.auth.products.abbott'
 }
 

Waiting for completion... 
Waiting for completion... 
Waiting for completion... 
Done!
