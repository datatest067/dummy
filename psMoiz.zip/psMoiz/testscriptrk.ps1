﻿ $context = Get-AzSubscription -SubscriptionId bef164d0-396c-4064-b5b0-2d2d9d986f4f

 Set-AzContext $context

 $vault = Get-AzRecoveryServicesVault -ResourceGroupName p1-nuin-rg52 -Name p1-nuin-rg52-rcv1

 C:\Users\MOIZMX\Documents\ps.txt =Get-AzRecoveryServicesBackupJob -Status "Failed" -VaultId $vault.ID|Out-File -FilePath C:\Users\MOIZMX\Documents\ps.txt

  Write-Output $joblist|Select-Object WorkloadName|Out-File -FilePath C:\Users\MOIZMX\Documents\ps.txt

  Get-Content -Path C:\Users\MOIZMX\Documents\ps.txt|Select-Object WorkloadName

 $Job = Backup-AzRecoveryServicesBackupItem -Item 'd1-ox-api-l522' -VaultId $vault.ID

Backup-AzRecoveryServicesBackupItem -ExpiryDateTimeUTC (get-date).AddDays(10) -Item $item -VaultId $jobresponse.vaultId


$vault = Get-AzRecoveryServicesVault -ResourceGroupName p1-nuin-rg52 -Name p1-nuin-rg52-rcv1

$NamedContainer = Get-AzRecoveryServicesBackupContainer -ContainerType AzureVM -Status Registered -FriendlyName "q1-ox-api-l522" -VaultId $vault.ID

$Item = Get-AzRecoveryServicesBackupItem -Container $NamedContainer -WorkloadType AzureVM -VaultId $vault.ID

$Job = Backup-AzRecoveryServicesBackupItem -Item $Item -VaultId $vault.ID

$joblist|Out-File -FilePath C:\Users\MOIZMX\Documents\ps147.txt

$joblist|Select-Object WorkloadName|Out-File -FilePath C:\Users\MOIZMX\Documents\ps147.txt


q1-ox-api-l522

Write-Output $item.LastBackupStatus == "Completed"
