﻿#Microsoft Azure Rest API authentication
#https://docs.microsoft.com/en-us/rest/api/azure/
$AzureConnection = Connect-AzAccount
$Subscriptions = (Get-AzSubscription).Id
$array = ("ec10dc7a-0abb-4fee-a727-bcd9d1cfbd36")
for($i=0; $i -lt $Subscriptions.Count; $i++)
{
   $SetSubscription = Set-AzContext -Subscription $Subscriptions[$i]
   $subscriptionId = $Subscriptions[$i]
  if($subscriptionId -ne $array)
  {
    #$SetSubscription = Set-AzContext -Subscription $Subscriptions[$i]
   
    #$subscriptionId = 'e937bd91-1543-4661-9c2f-26fb87db86d2'
    $subscriptionId = $Subscriptions[$i]
    $tenantId = '57064aa3-2825-4c10-a2e8-88c686234e09'
    $applicationId = 'ddbfd72e-0c3b-4fe0-83c2-4cbc88e5f730'
    $secret='Gct8Q~PfqYKPzgeYs80kw~wAdUOQFumiTZ1YHdeZ'

    #$param = @{
        #Uri = "https://login.microsoftonline.com/$tenantId/oauth2/token?api-version=1.0";
     #   Uri = "https://login.microsoftonline.com/$tenantId/oauth2/token?api-version=2020-06-01";
     #   Method = 'Post';
     #   Body = @{ 
     #       grant_type = 'client_credentials'; 
     #       resource = 'https://management.core.windows.net/'; 
     #       client_id = $applicationId; 
     #       client_secret = $secret
     #   }
    #}

        $Body = @{ 
            grant_type = 'client_credentials'; 
            resource = 'https://management.core.windows.net/'; 
            client_id = $applicationId; 
            client_secret = $secret
        }

    $LoginURL = 'https://login.windows.net'
    $result = Invoke-RestMethod –Method Post –Uri $LoginURL/$tenantId/oauth2/token –Body $Body

    $AuthKey = "Bearer " + $result.access_token
    $authHeader = @{
        'Content-Type'  = 'application/json;charset=utf-8'
        'Accept'        = 'application/json'
        'Authorization' = $AuthKey
    }
    
    $SubAPI = "https://management.azure.com/subscriptions/$subscriptionId/providers/Microsoft.ResourceHealth/availabilityStatuses?api-version=2018-07-01"
    $healthData = Invoke-RestMethod –Uri $SubAPI –Method GET –Headers $authHeader
    $Heathdata = $healthData.value | 
            Select-Object `
               @{n='subscriptionId';e={$_.id.Split("/")[2]}},
               location,
               @{n='resourceGroup';e={$_.id.Split("/")[4]}},
               @{n='resource';e={$_.id.Split("/")[8]}},
               @{n='status';e={$_.properties.availabilityState}}, # ie., Available or Unavailable
               @{n='summary';e={$_.properties.summary}},
               @{n='reason';e={$_.properties.reasonType}},
               @{n='occuredTime';e={$_.properties.occuredTime}},
               @{n='reportedTime';e={$_.properties.reportedTime}} |
            Format-List | Out-File -Append -FilePath $HOME\Desktop\test.txt

}
}
