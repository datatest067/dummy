﻿$AzureConnection = Connect-AzAccount
$Subscriptions = Get-AzSubscription
Set-AzContext -Subscription "27db1eb6-2b62-4710-98d6-28dc91f195aa"

$resourceGroupName="AzureBackupRG_eastus_1"
$actionGroupName="AG-DEMO-WE"
$actionshortName="AGDEMOWE"
 
$emailReceiver = New-AzActionGroupReceiver -Name 'moiz-email' -EmailReceiver -EmailAddress 'mohammed.moiz@abbott.com'
 
#$smsReceiver = New-AzActionGroupReceiver -Name 'moiz-sms' -SmsReceiver -CountryCode '+1' -PhoneNumber '0000000000'

#$webhookReceiver = New-AzActionGroupReceiver -Name 'jorge-web_hook' -WebhookReceiver -ServiceUri 'https://jorgebernhardt.com/alert'

#$tag = New-Object "System.Collections.Generic.Dictionary``2[System.String,System.String]"
#$tag.Add('environment', 'www.jorgebernhardt.com')
Set-AzActionGroup -Name $actionGroupName -ResourceGroup $resourceGroupName -ShortName $actionshortName -Receiver $emailReceiver
#, $smsReceiver, $webhookReceiver -Tag $tag

$actiongroup = Get-AzActionGroup -Name $actionGroupName -ResourceGroup $resourceGroupName -WarningAction Ignore
 
$ServiceHealthRegions = @(
                    "Central India",
                    "East US"
                    )
                     
$ServiceHealthServices = @(
                    "Action Groups",
                    "Activity Logs & Alerts",
                    "Alerts & Metrics",
                    "Alerts",
                    "Application Insights",
                    "Azure Active Directory",
                    "Azure Active Directory Domain Services"
                    )
 
 
$params = @{
    activityLogAlertName = "Temp Azure Service Notification"
    ServiceHealthRegions = $ServiceHealthRegions
    ServiceHealthServices = $ServiceHealthServices
    actiongroupresourceid = $actiongroup.id
}
 
New-AzResourceGroupDeployment `
    -Name "Azure-Service-Notification" `
    -ResourceGroupName $resourceGroupName `
    -TemplateFile "C:\Users\MOIZMX\Downloads\ServiceHealthAlert.json" `
    -TemplateParameterObject $params
    