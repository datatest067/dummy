﻿$AzureConnection = Connect-AzAccount

$tenantId = '57064aa3-2825-4c10-a2e8-88c686234e09'
$applicationId = 'ddbfd72e-0c3b-4fe0-83c2-4cbc88e5f730'
$secret='Gct8Q~PfqYKPzgeYs80kw~wAdUOQFumiTZ1YHdeZ'
$LoginURL = 'https://login.microsoftonline.com'

#Define Authentication Body Part
$Body = @{ 
            grant_type = 'client_credentials' 
            Scope         = "https://graph.microsoft.com/.default"
            client_id = $applicationId 
            client_secret = $secret
        }
#Run Rest API and generate Bearer Token
$result = Invoke-RestMethod –Method Post –Uri $LoginURL/$tenantId/oauth2/v2.0/token –Body $Body

 $authHeader = @{
         "Authorization" = "Bearer $($result.access_token)"
         "Content-type"  = "application/json"
     }
$Array = @()
$URLGetApps = "https://graph.microsoft.com/v1.0/applications"
$AllApps = Invoke-RestMethod -Uri $URLGetApps -Method GET -Headers $authHeader

$TimeSpanInDays=90


foreach ($App in $AllApps.value) {

    $URLGetApp = "https://graph.microsoft.com/v1.0/applications/$($App.ID)"
    $App = Invoke-RestMethod -Method GET -Uri $URLGetApp -Headers $authHeader

    if ($App.passwordCredentials) {
        foreach ($item in $App.passwordCredentials) {
            $Array += [PSCustomObject]@{
                "Type"           = "AZAPP"
                "displayName"    = $app.displayName
                "ID"             = $App.ID
                "AppID"          = $app.appId
                "SecType"        = "Secret"
                "Secret"         = $item.displayName
                "Secret-EndDate" = (Get-date $item.endDateTime)
            }
        }
    }
}

$ExpiredZerts = $Array | Where-Object -Property Secret-EndDate -Value (Get-Date).AddDays(0) -lt | Out-File -FilePath C:\Users\MOIZMX\Desktop\secrets\expired.csv -Append

$ExpireringSoonZerts = $Array | Where-Object -Property Secret-EndDate -Value (Get-Date).AddDays($TimeSpanInDays) -lt  | Where-Object -Property Secret-EndDate -Value (Get-Date) -gt | Out-File -FilePath C:\Users\MOIZMX\Desktop\secrets\expiringsoon.csv -Append

if(Test-Path -Path C:\Users\MOIZMX\Desktop\secrets\expiringsoon.csv){
$fileDateString = (Get-Date).ToString("dd-MMM-yyyy-HHmm")
$dateString = (Get-Date).ToString("dd-MMM-yyyy-HH:mm")

#####Variables####
$workingDirectory = "C:\Users\MOIZMX\Desktop\secrets\"
$token = "Mjc1MjgyMjEzMTEzOuRAdtnAbsSAA/WtcT2YH3qNg69/" ## Follow instructions at https://confluence.atlassian.com/enterprise/using-personal-access-tokens-1026032365.html to create token.
$project_id = "10101"
$issuetype_id = "10005"
$issue_summary = "App registration expiring soon - $dateString"
$issue_description = "App registration expiring soon."
$watchers = (
    "somsejx",
    "FATOKOX"
)



## Function to upload CSV to JIRA

function Upload-JiraCSV($filepath, $ticketid){
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("X-Atlassian-Token", "no-check")
    $headers.Add("Authorization", "Bearer $token")

      $fileName = "expiringsoon.csv"
        $filePath = $workingDirectory + $fileName

    $fileBytes = [System.IO.File]::ReadAllBytes($FilePath);
    $fileEnc = [System.Text.Encoding]::GetEncoding('UTF-8').GetString($fileBytes);
    $boundary = [System.Guid]::NewGuid().ToString(); 
    $LF = "`r`n";

    $bodyLines = ( 
        "--$boundary",
        "Content-Disposition: form-data; name=`"file`"; filename=`"$fileName`"",
        "Content-Type: application/octet-stream$LF",
        $fileEnc,
        "--$boundary--$LF" 
    ) -join $LF

    $response = Invoke-RestMethod "https://jira.merlin.net/rest/api/2/issue/$ticketid/attachments" -Method 'POST' -Headers $headers -Body $bodyLines -ContentType "multipart/form-data; boundary=`"$boundary`""
}

function Add-JiraTicketWatchers($watcher, $ticketid) {
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("X-Atlassian-Token", "no-check")
    $headers.Add("Authorization", "Bearer $token")

    $body = @"
    "$watcher"
"@

    $response = Invoke-RestMethod "https://jira.merlin.net/rest/api/2/issue/$ticketid/watchers" -Method 'POST' -Headers $headers -Body $body -ContentType "application/json"


}

function Create-JiraTicket() {
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("X-Atlassian-Token", "no-check")
    $headers.Add("Authorization", "Bearer $token")

    $body = @"
{
    "fields": {
       "project":
       {
          "id": "$project_id"
       },
       "summary": "$issue_summary",
       "description": "$issue_description",
       "issuetype": {
          "id": "$issuetype_id"
       },
       "priority": {
            "id": "1"
        },
        "components": [
            {
                "id": "10000"
            }
        ],
        "customfield_10009": "ptchange/getithelp"
   }
}
"@

    $response = Invoke-RestMethod "https://jira.merlin.net/rest/api/2/issue" -Method 'POST' -Headers $headers -Body $body -ContentType "application/json"

    return $response.id
}


    ####----Installing Az Module----####
    #This is one time acitvity will be required only if Az module is not installed.
    #Install-Module -Name Az -Force -Scope CurrentUser

    ####----Connecting to Azure Account----####
    Write-Host "Connecting to Azure Account" -ForegroundColor Green
    

    ####----Clearing our old CSV files----####
    $file = Get-ChildItem -Path $workingDirectory -Filter "*.csv" 

   

    $ticket_id = Create-JiraTicket

    ForEach ($watcher in $watchers) {
        Add-JiraTicketWatchers -watcher $watcher -ticketid $ticket_id
    }
    
    Upload-JiraCSV -filepath $file -ticketid $ticket_id

   }


