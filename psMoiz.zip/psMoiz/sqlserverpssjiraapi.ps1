﻿#####################################
# Script : Exporting the Role Assignment Details
# Created on : 13-04-2022
#####################################

####Constants####
$fileDateString = (Get-Date).ToString("dd-MMM-yyyy-HHmm")
$dateString = (Get-Date).ToString("dd-MMM-yyyy-HH:mm")

#####Variables####
$workingDirectory = "C:\Test\"
$token = "ODgwMjQ3MjAxOTAxOn6p3ooy3MzO0ACjBjHqRMjAFGHI" ## Follow instructions at https://confluence.atlassian.com/enterprise/using-personal-access-tokens-1026032365.html to create token.
$project_id = "10101"
$issuetype_id = "10005"
$issue_summary = "sqlserver networks Downloads - $dateString"
$issue_description = "sqlserver network detail export from the azure portal."
$watchers = (
    "somsejx",
    "FATOKOX"
)



## Function to upload CSV to JIRA

function Upload-JiraCSV($filepath, $ticketid){
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("X-Atlassian-Token", "no-check")
    $headers.Add("Authorization", "Bearer $token")

      $fileName = "sqlserverp.csv"
        $filePath = $workingDirectory + $fileName

    $fileBytes = [System.IO.File]::ReadAllBytes($FilePath);
    $fileEnc = [System.Text.Encoding]::GetEncoding('UTF-8').GetString($fileBytes);
    $boundary = [System.Guid]::NewGuid().ToString(); 
    $LF = "`r`n";

    $bodyLines = ( 
        "--$boundary",
        "Content-Disposition: form-data; name=`"file`"; filename=`"$fileName`"",
        "Content-Type: application/octet-stream$LF",
        $fileEnc,
        "--$boundary--$LF" 
    ) -join $LF

    $response = Invoke-RestMethod "https://jira.merlin.net/rest/api/2/issue/$ticketid/attachments" -Method 'POST' -Headers $headers -Body $bodyLines -ContentType "multipart/form-data; boundary=`"$boundary`""
}

function Add-JiraTicketWatchers($watcher, $ticketid) {
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("X-Atlassian-Token", "no-check")
    $headers.Add("Authorization", "Bearer $token")

    $body = @"
    "$watcher"
"@

    $response = Invoke-RestMethod "https://jira.merlin.net/rest/api/2/issue/$ticketid/watchers" -Method 'POST' -Headers $headers -Body $body -ContentType "application/json"


}

function Create-JiraTicket() {
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("X-Atlassian-Token", "no-check")
    $headers.Add("Authorization", "Bearer $token")

    $body = @"
{
    "fields": {
       "project":
       {
          "id": "$project_id"
       },
       "summary": "$issue_summary",
       "description": "$issue_description",
       "issuetype": {
          "id": "$issuetype_id"
       }
   }
}
"@

    $response = Invoke-RestMethod "https://jira.merlin.net/rest/api/2/issue" -Method 'POST' -Headers $headers -Body $body -ContentType "application/json"

    return $response.id
}


    ####----Installing Az Module----####
    #This is one time acitvity will be required only if Az module is not installed.
    #Install-Module -Name Az -Force -Scope CurrentUser

    ####----Connecting to Azure Account----####
    Write-Host "Connecting to Azure Account" -ForegroundColor Green
    

    ####----Clearing our old CSV files----####
    Get-ChildItem -Path $workingDirectory -Filter "*.csv" 

   

    $ticket_id = Create-JiraTicket

    ForEach ($watcher in $watchers) {
        Add-JiraTicketWatchers -watcher $watcher -ticketid $ticket_id
    }


        $fileName = "sqlserverp.csv"
        #$fileName = "RoleAssignmentDetails-"+ $subscription.Name + "-" + $fileDateString + ".csv"
        $filePath = $workingDirectory + $fileName

        ####---Declaring variable to save the details---####

        ####----Checking if role assignment is not null----####

        ####----Checking if File Already Exist----####
        Write-Host "Adding the details to the .csv file" -ForegroundColor Green
        if((Test-Path $filePath)){
            Upload-JiraCSV -filepath $filePath -ticketid $ticket_id
                
        }
        else{ 
            Write-Host "file not found"
            Upload-JiraCSV -filepath $filePath -ticketid $ticket_id
        }

    
    Write-Host "Script Execution Completed" -ForegroundColor Green

