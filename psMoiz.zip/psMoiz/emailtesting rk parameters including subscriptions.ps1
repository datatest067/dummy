﻿$connection = Get-AutomationConnection -Name AzureRunAsConnection
 $connectionResult = Connect-AzAccount `
 -ServicePrincipal `
 -Tenant $connection.TenantID `
 -ApplicationId $connection.ApplicationID `
 -CertificateThumbprint $connection.CertificateThumbprint
 "Login successful.."
    
 get-azcontext
    
 $query = "RecoveryServicesResources 
 | where type in~ ('microsoft.recoveryservices/vaults/backupjobs')
 | extend vaultName = case(type =~ 'microsoft.dataprotection/backupVaults/backupJobs',properties.vaultName,type =~ 'Microsoft.RecoveryServices/vaults/backupJobs',split(split(id, '/Microsoft.RecoveryServices/vaults/')[1],'/')[0],'--')
 | extend friendlyName = case(type =~ 'microsoft.dataprotection/backupVaults/backupJobs',strcat(properties.dataSourceSetName , '/', properties.dataSourceName),type =~ 'Microsoft.RecoveryServices/vaults/backupJobs', properties.entityFriendlyName, '--')
 | extend dataSourceType = case(type =~ 'Microsoft.RecoveryServices/vaults/backupJobs',properties.backupManagementType,type =~ 'microsoft.dataprotection/backupVaults/backupJobs',properties.dataSourceType,'--')
 | extend protectedItemName = split(split(properties.backupInstanceId, 'protectedItems')[1],'/')[1]
 | extend vaultId = tostring(split(id, '/backupJobs')[0])
 | extend vaultSub = tostring( split(id, '/')[2])
 | extend jobStatus = case (properties.status == 'Completed' or properties.status == 'CompletedWithWarnings','Succeeded',properties.status == 'Failed','Failed',properties.status == 'InProgress', 'Started', properties.status), operation = case(type =~ 'microsoft.dataprotection/backupVaults/backupJobs' and tolower(properties.operationCategory) =~ 'backup' and properties.isUserTriggered == 'true',strcat('adhoc',properties.operationCategory),type =~ 'microsoft.dataprotection/backupVaults/backupJobs', tolower(properties.operationCategory), type =~ 'Microsoft.RecoveryServices/vaults/backupJobs' and tolower(properties.operation) =~ 'backup' and properties.isUserTriggered == 'true',strcat('adhoc',properties.operation),type =~ 'Microsoft.RecoveryServices/vaults/backupJobs',tolower(properties.operation), '--'),startTime = todatetime(properties.startTime),endTime = properties.endTime, duration = properties.duration 
 | where startTime >= ago(24h)
 | where (dataSourceType in~ ('AzureIaasVM'))
 | where jobStatus=='Failed'
 | where operation == 'backup' or operation == 'adhocBackup'
 | project vaultSub, vaultId, protectedItemName, startTime, endTime, jobStatus, operation
 | sort by vaultSub"
    
 $subscriptions = Get-AzSubscription | foreach {$_.SubscriptionId}
    
 $result = Search-AzGraph -Subscription $subscriptions -Query $query -First 5
    
 $result = $result.data
    
 $result[0]
    
 $prevsub = ""
 foreach($jobresponse in $result)
 {
               if($jobresponse.vaultSub -ne $prevsub)
               {
                            Set-AzContext -SubscriptionId $jobresponse.vaultSub
                            $prevsub = $jobresponse.vaultSub
               }
    
               $item = Get-AzRecoveryServicesBackupItem -VaultId $jobresponse.vaultId -BackupManagementType AzureVM -WorkloadType AzureVM -Name $jobresponse.protectedItemName
    
               Backup-AzRecoveryServicesBackupItem -ExpiryDateTimeUTC (get-date).AddDays(10) -Item $item -VaultId $jobresponse.vaultId
    
 }


$ServiceName = Get-AzRecoveryServicesVault


 $vault1 = Get-AzRecoveryServicesVault -ResourceGroupName $ServiceName.ResourceGroupName -Name $ServiceName.Name

 

 $joblist1=Get-AzRecoveryServicesBackupJob -Status "Failed" -VaultId $vault1.ID

Write-Output $joblist1|Select-Object WorkloadName,Status,Starttime,Endtime,JobID|Out-File -FilePath C:\Users\MOIZMX\Documents\ps14778.txt

$Worklist=$joblist1|Select-Object WorkloadName,Status,Starttime,Endtime,JobID

 Get-Content -Path C:\Users\MOIZMX\Documents\ps.txt|Select-Object WorkloadName




 $NamedContainer = Get-AzRecoveryServicesBackupContainer -ContainerType AzureVM -Status Registered -FriendlyName "q1-ox-api-l611.auth.products.abbott" -VaultId $vault.ID

 $Item = Get-AzRecoveryServicesBackupItem -Container $NamedContainer -WorkloadType AzureVM -VaultId $vault.ID

 $Job = Backup-AzRecoveryServicesBackupItem -Item $Item -VaultId $vault.ID

 $job.Status

 $job.ActivityId

 $vault = Get-AzRecoveryServicesVault -ResourceGroupName "resourceGroup" -Name "vaultName"

$Jobs = Get-AzRecoveryServicesBackupJob -Status InProgress -VaultId $vault.ID

$Job = $Jobs[0]

While ( $Job.Status -ne "Completed" ) {
    Write-Host -Object "Waiting for completion..."
    Start-Sleep -Seconds 180
    $Job = Get-AzRecoveryServicesBackupJob -Job $Job -VaultId $vault.ID
}
if($Job.Status -eq "Completed") 
 {
    Send-MailMessage -From 'moiz <mohammed.moiz@abbott.com>' -To 'moiz <mohammed.moiz@abbott.com>' -Subject 'Recovery Backup Job resumed and completed successfully' -Body "$Job.ActivityId Recovery Backup Job resumed and completed successfully"   -SmtpServer 'smtp.auth.products.abbott'
 }
 

Waiting for completion... 
Waiting for completion... 
Waiting for completion... 
Done!


$ServiceName = Get-AzRecoveryServicesVault


 $vault1 = Get-AzRecoveryServicesVault -ResourceGroupName $ServiceName.ResourceGroupName -Name $ServiceName.Name

 

 $joblist1=Get-AzRecoveryServicesBackupJob -Status "Failed" -VaultId $vault1.ID

Write-Output $joblist1|Select-Object WorkloadName,Status,Starttime,Endtime,JobID|Out-File -FilePath C:\Users\MOIZMX\Documents\ps14778.txt

$Worklist=$joblist1|Select-Object WorkloadName,Status,Starttime,Endtime,JobID

 Get-Content -Path C:\Users\MOIZMX\Documents\ps.txt|Select-Object WorkloadName




 $NamedContainer = Get-AzRecoveryServicesBackupContainer -ContainerType AzureVM -Status Registered -FriendlyName "q1-ox-api-l611.auth.products.abbott" -VaultId $vault.ID

 $Item = Get-AzRecoveryServicesBackupItem -Container $NamedContainer -WorkloadType AzureVM -VaultId $vault.ID

 $Job = Backup-AzRecoveryServicesBackupItem -Item $Item -VaultId $vault.ID

 $job.Status

 $job.ActivityId

 $vault = Get-AzRecoveryServicesVault -ResourceGroupName "resourceGroup" -Name "vaultName"

$Jobs = Get-AzRecoveryServicesBackupJob -Status InProgress -VaultId $vault.ID

$Job = $Jobs[0]

While ( $Job.Status -ne "Completed" ) {
    Write-Host -Object "Waiting for completion..."
    Start-Sleep -Seconds 180
    $Job = Get-AzRecoveryServicesBackupJob -Job $Job -VaultId $vault.ID
}
if($Job.Status -eq "Completed") 
 {
    Send-MailMessage -From 'moiz <mohammed.moiz@abbott.com>' -To 'moiz <mohammed.moiz@abbott.com>' -Subject 'Recovery Backup Job resumed and completed successfully' -Body "$Job.ActivityId Recovery Backup Job resumed and completed successfully"   -SmtpServer 'smtp.auth.products.abbott'
 }
 

Waiting for completion... 
Waiting for completion... 
Waiting for completion... 
Done!
