﻿$secpasswd = ConvertTo-SecureString -String $(SECRET) -AsPlainText -Force
 $Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $(APPID), $secpasswd 
Connect-AzAccount -ServicePrincipal -TenantId $(TENANTID) -Credential $Credential -SubscriptionId 1234

 "Login successful.."
    
 get-azcontext
    
$query = "RecoveryServicesResources 
 | where type in~ ('microsoft.recoveryservices/vaults/backupjobs')
 | extend vaultName = case(type =~ 'microsoft.dataprotection/backupVaults/backupJobs',properties.vaultName,type =~ 'Microsoft.RecoveryServices/vaults/backupJobs',split(split(id, '/Microsoft.RecoveryServices/vaults/')[1],'/')[0],'--')
 | extend friendlyName = case(type =~ 'microsoft.dataprotection/backupVaults/backupJobs',strcat(properties.dataSourceSetName , '/', properties.dataSourceName),type =~ 'Microsoft.RecoveryServices/vaults/backupJobs', properties.entityFriendlyName, '--')
 | extend dataSourceType = case(type =~ 'Microsoft.RecoveryServices/vaults/backupJobs',properties.backupManagementType,type =~ 'microsoft.dataprotection/backupVaults/backupJobs',properties.dataSourceType,'--')
 | extend protectedItemName = split(split(properties.backupInstanceId, 'protectedItems')[1],'/')[1]
 | extend vaultId = tostring(split(id, '/backupJobs')[0])
 | extend vaultSub = tostring( split(id, '/')[2])
 | extend jobStatus = case (properties.status == 'Completed' or properties.status == 'CompletedWithWarnings','Succeeded',properties.status == 'Failed','Failed',properties.status == 'InProgress', 'Started', properties.status), operation = case(type =~ 'microsoft.dataprotection/backupVaults/backupJobs' and tolower(properties.operationCategory) =~ 'backup' and properties.isUserTriggered == 'true',strcat('adhoc',properties.operationCategory),type =~ 'microsoft.dataprotection/backupVaults/backupJobs', tolower(properties.operationCategory), type =~ 'Microsoft.RecoveryServices/vaults/backupJobs' and tolower(properties.operation) =~ 'backup' and properties.isUserTriggered == 'true',strcat('adhoc',properties.operation),type =~ 'Microsoft.RecoveryServices/vaults/backupJobs',tolower(properties.operation), '--'),startTime = todatetime(properties.startTime),endTime = properties.endTime, duration = properties.duration 
 | where startTime >= ago(48h)
 | where (dataSourceType in~ ('AzureIaasVM'))
 | where jobStatus=='Failed'
 | where operation == 'backup' or operation == 'adhocBackup'
 | project vaultSub, vaultId, protectedItemName, startTime, endTime, jobStatus, operation
 | sort by vaultSub"
    
 $subscriptions = Get-AzSubscription | foreach {$_.SubscriptionId}
    
 $result = Search-AzGraph -Subscription $subscriptions -Query $query 
    
 $result = $result.data
    
 $result[0]
    
 $prevsub = ""
 foreach($jobresponse in $result)
 {
               if($jobresponse.vaultSub -ne $prevsub)
               {
                            Set-AzContext -SubscriptionId $jobresponse.vaultSub
                            $prevsub = $jobresponse.vaultSub
               }
         $CSVFileLocation = "$HOME\Desktop\progress.csv"
         $CSVFile = "$HOME\Desktop\non-progress.csv"

         $jobstatus = (Get-AzRecoveryServicesBackupJob -VaultId $jobresponse.vaultid -Status inprogress).WorkloadName
        
         if(!$jobstatus)
         {
         write-output $jobresponse.protectedItemName |  Out-File -Append $CSVFile -Encoding string
    
               $item = Get-AzRecoveryServicesBackupItem -VaultId $jobresponse.vaultId -BackupManagementType AzureVM -WorkloadType AzureVM -Name $jobresponse.protectedItemName
         
          
               Backup-AzRecoveryServicesBackupItem -ExpiryDateTimeUTC (get-date).AddDays(50) -Item $item -VaultId $jobresponse.vaultId
         }
 }
